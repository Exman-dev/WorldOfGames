import CurrencyRoulleteGame
import GuessGame
import MemoryGame


def welcome(name):
    return f'Hello {name} and welcome to the World of Games (WoG).\nHere you can find many cool games to play.'

def load_game():
    game = input("""Please choose a game to play:
    1. Memory Game - a sequence of numbers will appear for 1 second and you have to
guess it back
    2. Guess Game - guess a number and see if you chose like the computer
    3. Currency Roulette - try and guess the value of a random amount of USD in ILS\n""")

    while game not in "123":
        game=input("Please select 1, 2 or 3\n")

    user_diff = input("""
Please select a difficulty between 1 to 5: """)
    print()
    while user_diff not in "12345":
        user_diff=input("Please select 1,2,3,4 or 5\n")
    user_diff = int(user_diff)
    if game == '1':
        if MemoryGame.play(user_diff):
            print("You win !")
        else:
            print("You lost! ")
    elif game == '2':
        if GuessGame.play(user_diff):
            print("You win !")
        else:
            print("You lost! ")
    elif game == '3':
        if CurrencyRoulleteGame.play(user_diff):
            print("You win !")
        else:
            print("You lost! ")




