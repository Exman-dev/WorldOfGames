import random
def get_money_interval(difficulty, total_val):
    return total_val-(5-difficulty), total_val +(5-difficulty)

def get_guess_from_user():
    user = input("Enter your guess: ")
    while True:
        try:
            user = int(user)
            break
        except:
            user = input(("Make sure you put a number: "))

    return user

def play(difficulty):
    money = random.randrange(1,101)
    print("What do you think is the value of the", money, "from USD to ILS")
    low,up = get_money_interval(difficulty, money)
    ans = get_guess_from_user()
    if ans <= up and ans >= low:

        return True
    else:

        return False

